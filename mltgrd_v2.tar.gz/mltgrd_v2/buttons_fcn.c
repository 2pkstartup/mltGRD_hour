#include <stdio.h>
#include <stdlib.h>
#include "hardware/gpio.h"
#include "hardware/timer.h"
#include "hardware/flash.h"
#include "hardware/sync.h"
#include "button.h"
#include "io_constants.h"

#define VERSION 2
//array of exposition times
uint16_t times[47];
//length of array
uint8_t times_length;

//4 timers - 2 minutes - developer
uint16_t timers_0_constant;
//array of timers
uint16_t timers_0[4];
//length of array
uint8_t timers_0_length;
//output for timers - leds
uint8_t timers_0_leds[4];

//4 timers - 4 minutes - fixer
uint16_t timers_1_constant;
//array of timers
uint16_t timers_1[4];
//length of array
uint8_t timers_1_length;
//output for timers - leds
uint8_t timers_1_leds[4];

//output array for digits - two sevensegment display - controled by 4511 CMOS
uint8_t digits[4];
//length of array
uint8_t digits_length;


uint8_t value_exposition_YY;
uint8_t value_exposition_MM;
uint8_t value_exposition;

uint16_t time_exposition;

uint8_t selector_YYMM;

uint8_t enlarger_value;
uint8_t dark_light_value;

//seting outputs - leds, relays and displays
void setup_io(void){
    //diagnostic led
    gpio_init(LED_PIN);
    gpio_set_dir(LED_PIN, GPIO_OUT);
    
    //BCD code
    gpio_init(BCD_0);
    gpio_set_dir(BCD_0,GPIO_OUT);
    gpio_init(BCD_1);
    gpio_set_dir(BCD_1,GPIO_OUT);
    gpio_init(BCD_2);
    gpio_set_dir(BCD_2,GPIO_OUT);
    gpio_init(BCD_3);
    gpio_set_dir(BCD_3,GPIO_OUT);
   
    //choosing digits
    gpio_init(DIGIT_1);
    gpio_set_dir(DIGIT_1,GPIO_OUT);
    gpio_init(DIGIT_2);
    gpio_set_dir(DIGIT_2,GPIO_OUT);

    //timers 2 mins
    gpio_init(LED_TIMER_0_0);
    gpio_set_dir(LED_TIMER_0_0,GPIO_OUT);
    gpio_init(LED_TIMER_0_1);
    gpio_set_dir(LED_TIMER_0_1,GPIO_OUT);
    gpio_init(LED_TIMER_0_2);
    gpio_set_dir(LED_TIMER_0_2,GPIO_OUT);
    gpio_init(LED_TIMER_0_3);
    gpio_set_dir(LED_TIMER_0_3,GPIO_OUT);

    //timers 4 mins
    gpio_init(LED_TIMER_1_0);
    gpio_set_dir(LED_TIMER_1_0,GPIO_OUT);
    gpio_init(LED_TIMER_1_1);
    gpio_set_dir(LED_TIMER_1_1,GPIO_OUT);
    gpio_init(LED_TIMER_1_2);
    gpio_set_dir(LED_TIMER_1_2,GPIO_OUT);
    gpio_init(LED_TIMER_1_3);
    gpio_set_dir(LED_TIMER_1_3,GPIO_OUT);

    //choosing gradation
    gpio_init(LED_MM);
    gpio_set_dir(LED_MM,GPIO_OUT);
    gpio_init(LED_YY);
    gpio_set_dir(LED_YY,GPIO_OUT);

    //output relays
    gpio_init(MAIN_RELAY);
    gpio_set_dir(MAIN_RELAY,GPIO_OUT);
    gpio_init(RESERVE);
    gpio_set_dir(RESERVE,GPIO_OUT);


}
//function for decoding from 10base to 2base - 1 digit
void bcdtor(uint8_t input){
    uint8_t dig = input;
    uint8_t bin[4]={0,0,0,0}; 
    
    //index
    uint8_t i=0;
    
    while (dig > 0) {
        bin[i++] = dig % 2;
        dig /= 2;
    }
    for(int i=0;i<digits_length;i++)
    {
        gpio_put(digits[digits_length-1-i],bin[i]);
        //time for relax - 4511
        sleep_us(2);
    }
}
//function for display integer <0,99> to 2 7-seg display
void displaytor(uint8_t input){
    //settin limits
    if(input>99)
    {
        input=99;
    }

    if(input<0)
    {
        input=0;
    }

    gpio_put(DIGIT_2,ON);
    sleep_us(2);
    gpio_put(DIGIT_1,ON);
    sleep_us(2);
    //first digit X0
    bcdtor(input/10);
    gpio_put(DIGIT_1,OFF);
    sleep_us(2);
    gpio_put(DIGIT_1,ON);
    sleep_us(2);
    //second digit 0X
    bcdtor(input%10);
    gpio_put(DIGIT_2,OFF);
    sleep_us(2);
    gpio_put(DIGIT_2,ON);
    sleep_us(2);
}

void Btn_up_setter(){
    printf("UP\n");   
    if(time_exposition==0)
    {    
        if(value_exposition<(times_length-1))
        {
            value_exposition++;
        }
        else
        {
            value_exposition=0;
        }
    }
}
void Btn_down_setter(){
    printf("DOWN\n");
    if(time_exposition==0)
    {
        if(value_exposition>0)
        {
            value_exposition--;
        }
        else
        {
            value_exposition=(times_length-1);
        }
    }
}
void Btn_timer_0_setter(){
    printf("TIMER_0\n");
    for (int i=0;i<timers_0_length;i++)
    {
        
        if (timers_0[i]==0)
        {
            timers_0[i]=+ timers_0_constant;
            break;
        }
    }        
}
void Btn_timer_1_setter(){
    printf("TIMER_1\n");
    for (int i=0;i<timers_1_length;i++)
    {
        if (timers_1[i]==0)
        {
            timers_1[i]=+ timers_1_constant;
            break;
        }
    }
}
void Btn_composition_setter(){
    printf("COMPOSITION\n");
    time_exposition = 0;
    enlarger_value = 1-enlarger_value;
    dark_light_value =1-dark_light_value;
}
void Btn_exposition_setter(){
    printf("EXPOSITION\n");       
    if (time_exposition==0)
    {
        time_exposition = times[value_exposition];
        enlarger_value = 1;  
        dark_light_value =1;
    }
}
void Btn_selector_yymm_setter(){
    if(time_exposition==0)
    {
        selector_YYMM=1-selector_YYMM;
        printf("YYMM %d\n",selector_YYMM);        
        if (selector_YYMM==0) //byl YY a jdeme do MM
        {
            value_exposition_YY=value_exposition;
            value_exposition=value_exposition_MM;
        }
        else
        {
            value_exposition_MM=value_exposition;
            value_exposition=value_exposition_YY;
        }        
    }

}

void initialization(){
    gpio_put(LED_TIMER_0_0,1);
    displaytor(11);
    gpio_put(LED_YY,ON);
    gpio_put(LED_MM,OFF);    
    sleep_ms(150);

    gpio_put(LED_TIMER_0_1,1);
    displaytor(22);    
    gpio_put(LED_YY,OFF);
    gpio_put(LED_MM,ON);
    sleep_ms(150);

    gpio_put(LED_TIMER_0_2,1);
    displaytor(33);    
    gpio_put(LED_YY,ON);
    gpio_put(LED_MM,OFF);
    sleep_ms(150);

    gpio_put(LED_TIMER_0_3,1);
    gpio_put(LED_TIMER_0_0,0);
    displaytor(44);    
    gpio_put(LED_YY,OFF);
    gpio_put(LED_MM,ON);
    sleep_ms(150);

    gpio_put(LED_TIMER_1_3,1);
    gpio_put(LED_TIMER_0_1,0);
    displaytor(55);    
    gpio_put(LED_YY,ON);
    gpio_put(LED_MM,OFF);
    sleep_ms(150);

    gpio_put(LED_TIMER_1_2,1);
    gpio_put(LED_TIMER_0_2,0);
    displaytor(66);    
    gpio_put(LED_YY,OFF);
    gpio_put(LED_MM,ON);
    sleep_ms(150);

    gpio_put(LED_TIMER_1_1,1);
    gpio_put(LED_TIMER_0_3,0);
    displaytor(77);    
    gpio_put(LED_YY,ON);
    gpio_put(LED_MM,OFF);
    sleep_ms(150);

    gpio_put(LED_TIMER_1_0,1);
    gpio_put(LED_TIMER_1_3,0);
    displaytor(88);    
    gpio_put(LED_YY,OFF);
    gpio_put(LED_MM,ON);
    sleep_ms(150);

    gpio_put(LED_TIMER_1_2,0);
    displaytor(99);    
    gpio_put(LED_YY,ON);
    gpio_put(LED_MM,OFF);
    sleep_ms(150);

    gpio_put(LED_TIMER_1_1,0);
    displaytor(00);    
    gpio_put(LED_YY,OFF);
    gpio_put(LED_MM,ON);
    sleep_ms(150);

    gpio_put(LED_TIMER_1_0,0);    
    gpio_put(LED_YY,ON);
    gpio_put(LED_MM,OFF);
    sleep_ms(150);

    displaytor(VERSION);
    sleep_ms(1000);
    gpio_put(LED_YY,OFF);
    gpio_put(LED_MM,OFF);
    displaytor(00);
}