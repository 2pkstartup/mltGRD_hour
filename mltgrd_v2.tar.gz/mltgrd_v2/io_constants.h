#ifndef IO_CONSTANTS_H
#define IO_CONSTANTS_H

/*  outputs  */
//
#define LED_PIN 25
//BCD code
#define BCD_0 17
#define BCD_1 10
#define BCD_2 11
#define BCD_3 13

//choosing digits
#define DIGIT_1 12
#define DIGIT_2 16

//timers 2 mins
#define LED_TIMER_0_0 2
#define LED_TIMER_0_1 4
#define LED_TIMER_0_2 6
#define LED_TIMER_0_3 8

//timers 4 mins
#define LED_TIMER_1_0 3
#define LED_TIMER_1_1 5
#define LED_TIMER_1_2 7
#define LED_TIMER_1_3 9

//choosing gradation
#define LED_MM 14
#define LED_YY 15

//output relays
#define MAIN_RELAY 26
#define RESERVE 22

/*  inputs  */

#define BTN_TIMER_0 0
#define BTN_TIMER_1 1
#define BTN_COMPOSITION 27
#define BTN_EXPOSITION 21
#define BTN_SELECTOR_YYMM 20
#define BTN_UP_TIME 19
#define BTN_DOWN_TIME 18

#define FLASH_TARGET_OFFSET (256 * 1024)
#endif