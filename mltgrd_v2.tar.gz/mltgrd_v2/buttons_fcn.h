#ifndef BUTTONS_FCN_H
#define BUTTONS_FCN_H
#include "pico/stdlib.h"
//seting outputs - leds, relays and displays
void setup_io(void);
//function for decoding from 10base to 2base - 1 digit
void bcdtor(uint8_t input);
//function for display integer <0,99> to 2 7-seg display
void displaytor(uint8_t input);
void Btn_up_setter();
void Btn_down_setter();
void Btn_timer_0_setter();
void Btn_timer_1_setter();
void Btn_composition_setter();
void Btn_exposition_setter();
void Btn_selector_yymm_setter();
void initialization();
#endif