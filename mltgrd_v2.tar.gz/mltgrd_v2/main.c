#include <stdio.h>
#include <stdlib.h>
#include "hardware/gpio.h"
#include "hardware/timer.h"
#include "hardware/flash.h"
#include "hardware/sync.h"
#include "hardware/watchdog.h"
#include "button.h"

#define VERSION 2
#define ON 1
#define OFF 0

//outputs
#define LED_PIN 25
//BCD code
#define BCD_0 17
#define BCD_1 10
#define BCD_2 11
#define BCD_3 13

//choosing digits
#define DIGIT_1 12
#define DIGIT_2 16

//timers 2 mins
#define LED_TIMER_0_0 2
#define LED_TIMER_0_1 4
#define LED_TIMER_0_2 6
#define LED_TIMER_0_3 8

//timers 4 mins
#define LED_TIMER_1_0 3
#define LED_TIMER_1_1 5
#define LED_TIMER_1_2 7
#define LED_TIMER_1_3 9

//choosing gradation
#define LED_MM 14
#define LED_YY 15

//output relays
#define MAIN_RELAY 26
#define RESERVE 22

//inputs

#define BTN_TIMER_0 0
#define BTN_TIMER_1 1
#define BTN_COMPOSITION 27
#define BTN_EXPOSITION 21
#define BTN_SELECTOR_YYMM 20
#define BTN_UP_TIME 19
#define BTN_DOWN_TIME 18

#define FLASH_TARGET_OFFSET (256 * 1024)


//length of array
const uint8_t times_length = 47;
//array of exposition times
uint16_t times[47];
//4 timers - 2 minutes - developer
uint16_t timers_0_constant;
//array of timers
uint16_t timers_0[]={0,0,0,0};
//length of array
const uint8_t timers_0_length = 4;
//output for timers - leds
uint8_t timers_0_leds[]={LED_TIMER_0_0,LED_TIMER_0_1,LED_TIMER_0_2,LED_TIMER_0_3};

//4 timers - 4 minutes - fixer
uint16_t timers_1_constant;
//array of timers
uint16_t timers_1[]={0,0,0,0};
//length of array
const uint8_t timers_1_length = 4;
//output for timers - leds
uint8_t timers_1_leds[]={LED_TIMER_1_0,LED_TIMER_1_1,LED_TIMER_1_2,LED_TIMER_1_3};

//output array for digits - two sevensegment display - controled by 4511 CMOS
uint8_t digits[]={BCD_3,BCD_2,BCD_1,BCD_0};
//length of array
const uint8_t digits_length = 4;


uint8_t value_exposition_YY;
uint8_t value_exposition_MM;
uint8_t value_exposition = 0;



uint16_t time_exposition = 0;

uint8_t selector_YYMM = 0;

uint8_t enlarger_value=0;
uint8_t dark_light_value=1;

const uint8_t *flash_target_contents = (const uint8_t *) (XIP_BASE + FLASH_TARGET_OFFSET);

//seting outputs - leds, relays and displays
void setup_io(void){
    //diagnostic led
    gpio_init(LED_PIN);
    gpio_set_dir(LED_PIN, GPIO_OUT);
    
    //BCD code
    gpio_init(BCD_0);
    gpio_set_dir(BCD_0,GPIO_OUT);
    gpio_init(BCD_1);
    gpio_set_dir(BCD_1,GPIO_OUT);
    gpio_init(BCD_2);
    gpio_set_dir(BCD_2,GPIO_OUT);
    gpio_init(BCD_3);
    gpio_set_dir(BCD_3,GPIO_OUT);
   
    //choosing digits
    gpio_init(DIGIT_1);
    gpio_set_dir(DIGIT_1,GPIO_OUT);
    gpio_init(DIGIT_2);
    gpio_set_dir(DIGIT_2,GPIO_OUT);

    //timers 2 mins
    gpio_init(LED_TIMER_0_0);
    gpio_set_dir(LED_TIMER_0_0,GPIO_OUT);
    gpio_init(LED_TIMER_0_1);
    gpio_set_dir(LED_TIMER_0_1,GPIO_OUT);
    gpio_init(LED_TIMER_0_2);
    gpio_set_dir(LED_TIMER_0_2,GPIO_OUT);
    gpio_init(LED_TIMER_0_3);
    gpio_set_dir(LED_TIMER_0_3,GPIO_OUT);

    //timers 4 mins
    gpio_init(LED_TIMER_1_0);
    gpio_set_dir(LED_TIMER_1_0,GPIO_OUT);
    gpio_init(LED_TIMER_1_1);
    gpio_set_dir(LED_TIMER_1_1,GPIO_OUT);
    gpio_init(LED_TIMER_1_2);
    gpio_set_dir(LED_TIMER_1_2,GPIO_OUT);
    gpio_init(LED_TIMER_1_3);
    gpio_set_dir(LED_TIMER_1_3,GPIO_OUT);

    //choosing gradation
    gpio_init(LED_MM);
    gpio_set_dir(LED_MM,GPIO_OUT);
    gpio_init(LED_YY);
    gpio_set_dir(LED_YY,GPIO_OUT);

    //output relays
    gpio_init(MAIN_RELAY);
    gpio_set_dir(MAIN_RELAY,GPIO_OUT);
    gpio_init(RESERVE);
    gpio_set_dir(RESERVE,GPIO_OUT);


}
//function for decoding from 10base to 2base - 1 digit
void bcdtor(uint8_t input){
    uint8_t dig = input;
    uint8_t bin[4]={0,0,0,0}; 
    
    //index
    uint8_t i=0;
    
    while (dig > 0) {
        bin[i++] = dig % 2;
        dig /= 2;
    }
    for(int i=0;i<digits_length;i++)
    {
        gpio_put(digits[digits_length-1-i],bin[i]);
        //time for relax - 4511
        sleep_us(2);
    }
}
//function for display integer <0,99> to 2 7-seg display
void displaytor(uint8_t input){
    //settin limits
    if(input>99)
    {
        input=99;
    }

    if(input<0)
    {
        input=0;
    }

    gpio_put(DIGIT_2,ON);
    sleep_us(2);
    gpio_put(DIGIT_1,ON);
    sleep_us(2);
    //first digit X0
    bcdtor(input/10);
    gpio_put(DIGIT_1,OFF);
    sleep_us(2);
    gpio_put(DIGIT_1,ON);
    sleep_us(2);
    //second digit 0X
    bcdtor(input%10);
    gpio_put(DIGIT_2,OFF);
    sleep_us(2);
    gpio_put(DIGIT_2,ON);
    sleep_us(2);
}
//timer 100 ms
bool repeating_timer_callback(struct repeating_timer *t){
    //decreasing 2/4 minute timers if not null by 0.1 sec
    for(int i =0;i<timers_0_length;i++){
        if(timers_0[i]>0)
        {
            timers_0[i]--;         
        }        
        if(timers_1[i]>0)
        {
            timers_1[i]--;        
        }
    //output status of timers
        gpio_put(timers_0_leds[i],timers_0[i]);     

        gpio_put(timers_1_leds[i],timers_1[i]);
    }
    
    //if exposition, decrease and display
    if (time_exposition>0) 
    {
        time_exposition--;
        //display seconds
        displaytor(time_exposition/10);    
        //if finish of exposition
        if (time_exposition==0)
        {   //turn off enlarger relay
            enlarger_value = 0;     
        }        
    }
    else
    {
       displaytor(times[value_exposition]/10);       
    }
    //diagnostic output via USB    
    printf("%d %d %d %d %d %d %d %d %d %d %d %d %d\n",timers_0[0],timers_0[1],timers_0[2],timers_0[3],timers_1[0],timers_1[1],timers_1[2],timers_1[3],time_exposition, value_exposition,value_exposition_YY, value_exposition_MM,enlarger_value);
    //output relay - set status
    gpio_put(MAIN_RELAY,enlarger_value);
    //second relay - set status
    gpio_put(RESERVE,enlarger_value);

    //select gradation -set status
    gpio_put(LED_YY,1-selector_YYMM);
    gpio_put(LED_MM,selector_YYMM);
    
    return true;
}
void Btn_up_setter(){
    printf("UP\n");   
    if(time_exposition==0)
    {    
        if(value_exposition<(times_length-1))
        {
            value_exposition++;
        }
        else
        {
            value_exposition=0;
        }
    }
}
void Btn_down_setter(){
    printf("DOWN\n");
    if(time_exposition==0)
    {
        if(value_exposition>0)
        {
            value_exposition--;
        }
        else
        {
            value_exposition=(times_length-1);
        }
    }
}
void Btn_timer_0_setter(){
    printf("TIMER_0\n");
    for (int i=0;i<timers_0_length;i++)
    {
        
        if (timers_0[i]==0)
        {
            timers_0[i]=+ timers_0_constant;
            break;
        }
    }        
}
void Btn_timer_1_setter(){
    printf("TIMER_1\n");
    for (int i=0;i<timers_1_length;i++)
    {
        if (timers_1[i]==0)
        {
            timers_1[i]=+ timers_1_constant;
            break;
        }
    }
}
void Btn_composition_setter(){
    printf("COMPOSITION\n");
    time_exposition = 0;
    enlarger_value = 1-enlarger_value;
    dark_light_value =1-dark_light_value;
}
void Btn_exposition_setter(){
    printf("EXPOSITION\n");       
    if (time_exposition==0)
    {
        time_exposition = times[value_exposition];
        enlarger_value = 1;  
        dark_light_value =1;
    }
}
void Btn_selector_yymm_setter(){
    if(time_exposition==0)
    {
        selector_YYMM=1-selector_YYMM;
        printf("YYMM %d\n",selector_YYMM);        
        if (selector_YYMM==0) //byl YY a jdeme do MM
        {
            value_exposition_YY=value_exposition;
            value_exposition=value_exposition_MM;
        }
        else
        {
            value_exposition_MM=value_exposition;
            value_exposition=value_exposition_YY;
        }        
    }

}
void onchange(button_t *button_p) {
  button_t *button = (button_t*)button_p;

  if(button->state) return; 

  switch(button->pin){
    case BTN_UP_TIME: 
        Btn_up_setter();
        break;
    case BTN_DOWN_TIME:
        Btn_down_setter();
        break;
    case BTN_TIMER_0:
        Btn_timer_0_setter();
        break;
    case BTN_TIMER_1:
        Btn_timer_1_setter();
        break;    
    case BTN_COMPOSITION:
        Btn_composition_setter();
        break;
    case BTN_EXPOSITION: 
        Btn_exposition_setter();        
        break;
    case BTN_SELECTOR_YYMM:        
        Btn_selector_yymm_setter();
        break;
  }
}
void initialization(){
    gpio_put(LED_TIMER_0_0,1);
    displaytor(11);
    gpio_put(LED_YY,ON);
    gpio_put(LED_MM,OFF);    
    sleep_ms(150);

    gpio_put(LED_TIMER_0_1,1);
    displaytor(22);    
    gpio_put(LED_YY,OFF);
    gpio_put(LED_MM,ON);
    sleep_ms(150);

    gpio_put(LED_TIMER_0_2,1);
    displaytor(33);    
    gpio_put(LED_YY,ON);
    gpio_put(LED_MM,OFF);
    sleep_ms(150);

    gpio_put(LED_TIMER_0_3,1);
    gpio_put(LED_TIMER_0_0,0);
    displaytor(44);    
    gpio_put(LED_YY,OFF);
    gpio_put(LED_MM,ON);
    sleep_ms(150);

    gpio_put(LED_TIMER_1_3,1);
    gpio_put(LED_TIMER_0_1,0);
    displaytor(55);    
    gpio_put(LED_YY,ON);
    gpio_put(LED_MM,OFF);
    sleep_ms(150);

    gpio_put(LED_TIMER_1_2,1);
    gpio_put(LED_TIMER_0_2,0);
    displaytor(66);    
    gpio_put(LED_YY,OFF);
    gpio_put(LED_MM,ON);
    sleep_ms(150);

    gpio_put(LED_TIMER_1_1,1);
    gpio_put(LED_TIMER_0_3,0);
    displaytor(77);    
    gpio_put(LED_YY,ON);
    gpio_put(LED_MM,OFF);
    sleep_ms(150);

    gpio_put(LED_TIMER_1_0,1);
    gpio_put(LED_TIMER_1_3,0);
    displaytor(88);    
    gpio_put(LED_YY,OFF);
    gpio_put(LED_MM,ON);
    sleep_ms(150);

    gpio_put(LED_TIMER_1_2,0);
    displaytor(99);    
    gpio_put(LED_YY,ON);
    gpio_put(LED_MM,OFF);
    sleep_ms(150);

    gpio_put(LED_TIMER_1_1,0);
    displaytor(00);    
    gpio_put(LED_YY,OFF);
    gpio_put(LED_MM,ON);
    sleep_ms(150);

    gpio_put(LED_TIMER_1_0,0);    
    gpio_put(LED_YY,ON);
    gpio_put(LED_MM,OFF);
    sleep_ms(150);

    displaytor(VERSION);
    sleep_ms(1000);
    gpio_put(LED_YY,OFF);
    gpio_put(LED_MM,OFF);
    displaytor(00);
}
void factory_reset()
{
    uint8_t config_data[FLASH_PAGE_SIZE];

    for (int i = 0; i < FLASH_PAGE_SIZE; ++i)
    {
        config_data[i] = 0xFF;
    }

    uint16_t init ;
    uint8_t cnt=0;

    uint16_t times[]={10,20,30,40,50,60,70,80,90,100,110,120,130,140,150,160,170,180,190,200,210,220,224,250,270,280,300,320,340,360,380,400,420,450,480,510,540,570,600,640,680,720,760,800,850,900,960,00,00};
    //length of array
    const uint8_t times_length = 47;

    //32  18  00  00    
    //

    init= 0x2012; 
    config_data[cnt++]=init>>8;     //32        0
    config_data[cnt++]=init&0xff;   //18        1
    config_data[cnt++]=0x00;        //2
    config_data[cnt++]=0x00;        //3    
    //TIMER_0_CONSTANT
    init= 1200;         
    config_data[cnt++]=init>>8;        //4
    config_data[cnt++]=init&0xff;      //5
    //TIMER_1_CONSTANT
    init= 2400;
    config_data[cnt++]=init>>8;         //6
    config_data[cnt++]=init&0xff;       //7

    const uint8_t value_exposition_YY=15;
    const uint8_t value_exposition_MM=42;

    config_data[cnt++]=00;              //8
    config_data[cnt++]=value_exposition_MM;//9
    config_data[cnt++]=00;                 //10
    config_data[cnt++]=value_exposition_YY;//11
    config_data[cnt++]=00;                  //12

    config_data[cnt++]=times_length;        //13


    for (int i =0;i<47;i++)
    {
        init= times[i];
        config_data[cnt++]=init>>8;
        config_data[cnt++]=init&0xff;
    }    

    uint32_t ints = save_and_disable_interrupts();
    flash_range_program(FLASH_TARGET_OFFSET, config_data, FLASH_PAGE_SIZE);
    restore_interrupts (ints);

    sleep_ms(2000);
    displaytor(88);
    sleep_ms(200);
    displaytor(0);
    sleep_ms(200);
    displaytor(88);
    sleep_ms(200);
    displaytor(0);
    sleep_ms(200);
    displaytor(88);
    watchdog_enable(1, 1);
    while(1);
}
int main(void){
    stdio_init_all();
    setup_io();

    //load from flash
    const uint8_t *buf = flash_target_contents;
    //header
    uint16_t header = (buf[0]<<8)+buf[1];
    if (header==0x2012)
    {
        timers_0_constant = (buf[4]<<8)+buf[5];
        timers_1_constant = (buf[6]<<8)+buf[7];
        value_exposition_MM = buf[9];
        value_exposition_YY = buf[11];

        uint8_t c=14;
        for (int i=0;i<times_length;i++)
        {
            times[i]=(buf[c++]<<8)+buf[c++];
        }
    }
    else
    {
        displaytor(88);    
        sleep_ms(3000);
        factory_reset();
    }

    if (!gpio_get(BTN_TIMER_0) && !gpio_get(BTN_TIMER_1))
    {
        displaytor(88);    
        sleep_ms(3000);
        factory_reset();
    }

    
    initialization();
    
   
    //initialization
    if (selector_YYMM==0)
    {
        value_exposition=value_exposition_MM;
        gpio_put(LED_YY,OFF);
        gpio_put(LED_MM,ON);
    }
    else
    {
        value_exposition=value_exposition_YY;
        gpio_put(LED_YY,ON);
        gpio_put(LED_MM,OFF);
    }
    gpio_put(MAIN_RELAY,OFF);
    gpio_put(RESERVE,OFF);

    struct  repeating_timer timer;
    add_repeating_timer_ms(100,repeating_timer_callback,NULL,&timer);
    
    button_t *btn_timmer_0 = create_button(BTN_TIMER_0, onchange);
    button_t *btn_timer_1 = create_button(BTN_TIMER_1, onchange);
    button_t *btn_composition = create_button(BTN_COMPOSITION, onchange);
    button_t *btn_exposition = create_button(BTN_EXPOSITION, onchange);
    button_t *btn_selector_yymm = create_button(BTN_SELECTOR_YYMM, onchange);
    button_t *btn_up_time = create_button(BTN_UP_TIME, onchange);
    button_t *btn_down_time = create_button(BTN_DOWN_TIME, onchange);

    while (1) 
    {        
        tight_loop_contents();
    }
   
    return(0);
}

